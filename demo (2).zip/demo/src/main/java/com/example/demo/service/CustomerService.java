package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public List<Customer> getAll() {
        return customerRepository.findAll();
    }

    public Customer save(Customer c) {
        return customerRepository.save(c);
    }

    public Customer update(Long id, Customer newC) {
        return customerRepository.findById(id)
                .map(c -> {
                    c.setFirstName(newC.getFirstName());
                    c.setLastName(newC.getLastName());
                    c.setEmail(newC.getEmail());
                    c.setAddress(newC.getAddress());
                    return customerRepository.save(c);
                }).orElseThrow(() -> new RuntimeException("Client non trouvé"));
    }

    public void delete(Long id) {
        customerRepository.deleteById(id);
    }
}
