package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAll() {
        return productRepository.findAll();
    }

    public Product save(Product product) {
        return productRepository.save(product);
    }

    public Product update(Long id, Product newProduct) {
        return productRepository.findById(id)
                .map(p -> {
                    p.setName(newProduct.getName());
                    p.setDescription(newProduct.getDescription());
                    p.setPrice(newProduct.getPrice());
                    p.setStockQuantity(newProduct.getStockQuantity());
                    p.setCategory(newProduct.getCategory());
                    return productRepository.save(p);
                }).orElseThrow(() -> new RuntimeException("Produit non trouvé"));
    }

    public void delete(Long id) {
        productRepository.deleteById(id);
    }
}