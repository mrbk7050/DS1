package com.example.demo.Iservice;

import java.util.List;

import com.example.demo.entity.Customer;

public interface ICustomerService {

    List<Customer> getAllCustomers();

    Customer getCustomerById(Long id);

    Customer addCustomer(Customer customer);

    Customer updateCustomer(Long id, Customer customer);

    void deleteCustomer(Long id);
}
